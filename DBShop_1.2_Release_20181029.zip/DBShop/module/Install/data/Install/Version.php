<?php
define('DBSHOP_VERSION', 'V 1.2 Release 20181029');
define('DBSHOP_VERSION_NUMBER', 1.12018102900);
define('DBSHOP_CHARSET', 'UTF-8');
define('DBSHOP_INSTALL_TIME', '{install_time}');
define('DBSHOP_UPDATE_TIME', '2018-10-29');