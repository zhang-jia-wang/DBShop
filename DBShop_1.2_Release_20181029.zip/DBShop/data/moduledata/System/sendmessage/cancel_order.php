亲爱的{buyname}：
       您在{shopname}于{canceltime}取消订单，订单编号为{ordersn}，详细信息请查看{shopurl}