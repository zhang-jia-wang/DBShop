亲爱的{askusername}：
       {replyusername}已于{replytime}对您在{shopname}的商品{goodsname}中提出的咨询进行了回复，请您及时查看。