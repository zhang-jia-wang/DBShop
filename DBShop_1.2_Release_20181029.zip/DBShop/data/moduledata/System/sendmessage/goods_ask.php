亲爱的{askusername}：
       您在{shopname}于{asktime}对商品{goodsname}提出咨询内容，谢谢您的热情参与，我们将尽快回复。