亲爱的{buyname}：
       {shopname}在{finishtime}已经为您完成订单交易，订单编号为{ordersn}。详细信息请查看{shopurl}