亲爱的{buyname}：
        您于{submittime}在{shopname}提交订单，订单编号为{ordersn} 请及时进行后续处理。具体操作请访问{shopurl}