亲爱的{buyname}：
        您于{paymenttime} 在{shopname} 完成付款，订单编号为{ordersn}，等待卖家发货。详细信息请查看{shopurl}