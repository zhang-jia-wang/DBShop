<div class="row-fluid" style="padding-top:1px; padding-bottom:5px;>
	<div class="span12">
    <a target="_blank" href=""><img src="/zf2/zftrunk/public/upload/ad/37/4.png" border='0' class="span12" /></a>
    </div>
</div>