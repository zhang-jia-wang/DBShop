<div class="columns"><div id="myCarousel1388669928" class="well carousel slide" style="padding: 0 0 0 0;">
            <div class="carousel-inner">
            
            <div class="active item">
            <a target="_blank" href=""><img src="/zf2/zftrunk/public/upload/ad/33/1.png"></a>
                <div class="carousel-caption">
                  <p>广告图片1</p>
                </div>
            </div>
            
            <div class="item">
            <a target="_blank" href=""><img src="/zf2/zftrunk/public/upload/ad/33/2.png"></a>
                <div class="carousel-caption">
                  <p>广告图片2</p>
                </div>
            </div>
            
            <div class="item">
            <a target="_blank" href=""><img src="/zf2/zftrunk/public/upload/ad/33/3.png"></a>
                <div class="carousel-caption">
                  <p>广告图片3</p>
                </div>
            </div>
            
            <div class="item">
            <a target="_blank" href=""><img src="/zf2/zftrunk/public/upload/ad/33/4.png"></a>
                <div class="carousel-caption">
                  <p>广告图片4</p>
                </div>
            </div>
            
            <div class="item">
            <a target="_blank" href=""><img src="/zf2/zftrunk/public/upload/ad/33/5.png"></a>
                <div class="carousel-caption">
                  <p>广告图片5</p>
                </div>
            </div>
            
            </div>
            <a class="carousel-control left" href="#myCarousel1388669928" data-slide="prev">&lsaquo;</a>
            <a class="carousel-control right" href="#myCarousel1388669928" data-slide="next">&rsaquo;</a>
            </div></div>