<div class="span12 sub_menu" style="margin-bottom:10px;">
<a target="_blank" href=""><img src="/zf2/zftrunk/public/upload/ad/34/3.png" border='0' class="span12" /></a>
</div>