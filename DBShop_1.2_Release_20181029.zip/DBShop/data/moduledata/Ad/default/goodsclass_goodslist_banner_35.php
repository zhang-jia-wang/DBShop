<div class="row-fluid">
	<div class="span10 offset1">
	 <a target="_blank" href=""><img src="/zf2/zftrunk/public/upload/ad/35/1.png" border='0' class="span12" /></a>
	</div>
</div>