<?php
define('DBSHOP_TIMEZONE', 'Asia/Shanghai');
define('DBSHOP_TEMPLATE', 'default');
define('DBSHOP_TEMPLATE_CSS', 'default');
define('DBSHOP_ADMIN_COMPRESS', 'false');
define('DBSHOP_FRONT_COMPRESS', 'false');
define('DBSHOP_PHONE_TEMPLATE', 'default');
define('DBSHOP_PHONE_TEMPLATE_CSS', 'default');
