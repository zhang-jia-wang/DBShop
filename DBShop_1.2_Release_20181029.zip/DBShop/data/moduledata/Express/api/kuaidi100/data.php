<?php
return array(
    'express' => array(
        0 => array(
            'express_name' => '顺丰速运',
            'express_code' => 'shunfeng',
        ),
        1 => array(
            'express_name' => '申通快递',
            'express_code' => 'shentong',
        ),
        2 => array(
            'express_name' => '圆通快递',
            'express_code' => 'yuantong',
        ),
        3 => array(
            'express_name' => 'EMS',
            'express_code' => 'ems',
        ),
        4 => array(
            'express_name' => '中通速递',
            'express_code' => 'zhongtong',
        ),
        5 => array(
            'express_name' => '韵达快递',
            'express_code' => 'yunda',
        ),
        6 => array(
            'express_name' => '天天快递',
            'express_code' => 'tiantian',
        ),
        7 => array(
            'express_name' => '全峰快递',
            'express_code' => 'quanfengkuaidi',
        ),
        8 => array(
            'express_name' => '汇通快递',
            'express_code' => 'huitongkuaidi',
        ),
        9 => array(
            'express_name' => '德邦物流',
            'express_code' => 'debangwuliu',
        ),
        10 => array(
            'express_name' => '宅急送',
            'express_code' => 'zhaijisong',
        ),
        11 => array(
            'express_name' => '全一快递',
            'express_code' => 'quanyikuaidi',
        ),
        12 => array(
            'express_name' => '民航快递',
            'express_code' => 'minghangkuaidi',
        ),
        13 => array(
            'express_name' => '华宇物流',
            'express_code' => 'tiandihuayu',
        ),
        14 => array(
            'express_name' => '中铁快运',
            'express_code' => 'zhongtiewuliu',
        ),
        15 => array(
            'express_name' => 'FedEx',
            'express_code' => 'fedex',
        ),
        16 => array(
            'express_name' => 'UPS',
            'express_code' => 'ups',
        ),
        17 => array(
            'express_name' => 'DHL',
            'express_code' => 'dhl',
        ),
    ),
);
