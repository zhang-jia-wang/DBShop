<?php
return array(
    'name' => '快递100',
    'name_code' => 'kuaidi100',
    'api_code' => '',
);
